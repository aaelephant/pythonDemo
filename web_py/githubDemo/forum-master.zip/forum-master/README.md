forum
=====

a simple forum based on web.py


see details here: http://www.cnblogs.com/russellluo/p/3240564.html


<hr />
<h4>latest update</h4>
<ol>
<li>"add support for editing post"</li>
<li>"turn the poor textarea into a full featured rich text editor(i.e. CLEditor) for adding/editing post"</li>
</ol>
